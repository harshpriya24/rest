package com.cg.employeemanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages= {"com.cg.employeemanagement"})
@EntityScan(basePackages="com.cg.employeemanagement.beans")
@EnableJpaRepositories(basePackages="com.cg.employeemanagement.daoservices")
public class CgEmployeeManagementPortalSpringBootMvcrestjpaData3Application {

	public static void main(String[] args) {
		SpringApplication.run(CgEmployeeManagementPortalSpringBootMvcrestjpaData3Application.class, args);
	}

}
