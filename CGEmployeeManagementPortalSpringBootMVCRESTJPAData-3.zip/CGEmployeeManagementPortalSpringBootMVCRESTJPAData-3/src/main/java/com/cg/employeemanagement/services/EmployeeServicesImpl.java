package com.cg.employeemanagement.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.employeemanagement.beans.Employee;
import com.cg.employeemanagement.daoservices.EmployeeDaoServices;
import com.cg.employeemanagement.exception.EmployeeNotFoundException;
@Component("employeeServices")
public class EmployeeServicesImpl implements EmployeeServices{
   @Autowired
	private EmployeeDaoServices employeeDAOServices;
	@Override
	public Employee acceptEmployeeDetails(Employee employee) {
		return employeeDAOServices.save(employee);
	}

	@Override
	public List<Employee> getAllEmployees() {
		List<Employee> employees=employeeDAOServices.findAll();
		return employees;
	}

	@Override
	public boolean removeEmployeeDetails(int employeeId) throws EmployeeNotFoundException {
    	employeeDAOServices.delete(getEmployeeDetails(employeeId));
		return true;
	}

	@Override
	public Employee getEmployeeDetails(int employeeId) throws EmployeeNotFoundException {
		return employeeDAOServices.findById(employeeId).orElseThrow(()->new EmployeeNotFoundException("Employee not found for For id"+employeeId));
	}

}
