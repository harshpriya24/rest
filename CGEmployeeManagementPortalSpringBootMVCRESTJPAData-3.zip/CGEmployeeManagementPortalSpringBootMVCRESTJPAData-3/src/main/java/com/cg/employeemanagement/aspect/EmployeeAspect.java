package com.cg.employeemanagement.aspect;

import org.springframework.web.bind.annotation.ControllerAdvice;

@ControllerAdvice
public class EmployeeAspect {

}
