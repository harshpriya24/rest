package com.cg.employeemanagement.beans;

import javax.persistence.Embeddable;

@Embeddable
public class Address {

	private String houseNo;
	private String homecity;
	private String homestate;
	private String pinCode;

	public Address(String houseNo, String homecity, String homestate, String pinCode) {
		super();
		this.houseNo = houseNo;
		this.homecity = homecity;
		this.homestate = homestate;
		this.pinCode = pinCode;
	}
public Address() {}
	public String getHouseNo() {
		return houseNo;
	}

	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}

	public String getHomecity() {
		return homecity;
	}

	public void setHomecity(String homecity) {
		this.homecity = homecity;
	}

	public String getHomestate() {
		return homestate;
	}

	public void setHomestate(String homestate) {
		this.homestate = homestate;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	@Override
	public String toString() {
		return "Address [houseNo=" + houseNo + ", homecity=" + homecity + ", homestate=" + homestate + ", pinCode="
				+ pinCode + "]";
	}

}
