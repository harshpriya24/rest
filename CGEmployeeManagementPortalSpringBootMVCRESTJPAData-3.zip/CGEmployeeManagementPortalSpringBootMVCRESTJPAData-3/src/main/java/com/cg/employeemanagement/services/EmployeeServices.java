package com.cg.employeemanagement.services;

import java.util.List;

import com.cg.employeemanagement.beans.Employee;
import com.cg.employeemanagement.exception.EmployeeNotFoundException;

public interface EmployeeServices {
	public Employee acceptEmployeeDetails(Employee employee);
	List<Employee> getAllEmployees();
	public boolean removeEmployeeDetails(int employeeId)throws EmployeeNotFoundException;
	public Employee getEmployeeDetails(int employeeId)throws EmployeeNotFoundException;
}
