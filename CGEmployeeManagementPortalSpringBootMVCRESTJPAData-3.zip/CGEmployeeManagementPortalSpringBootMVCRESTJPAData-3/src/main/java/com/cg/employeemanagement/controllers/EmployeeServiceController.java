package com.cg.employeemanagement.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.employeemanagement.beans.Employee;
import com.cg.employeemanagement.exception.EmployeeNotFoundException;
import com.cg.employeemanagement.services.EmployeeServices;

@Controller
public class EmployeeServiceController {
	@Autowired
	private EmployeeServices services;
	
	@RequestMapping(value="/acceptEmployeeDetails",method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
 public ResponseEntity<String> acceptEmployeeDetails(@ModelAttribute Employee employee){
 employee=services.acceptEmployeeDetails(employee);
 return new ResponseEntity<>("Employee registered  successfully with Id "+employee.getEmployeeId(),HttpStatus.OK);
 }
	@RequestMapping(value= {"/getEmployeeDetails/{employeeId}"},method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
 public ResponseEntity<Employee> getEmployeeDetails(@PathVariable(value="employeeId") int employeeId) throws EmployeeNotFoundException{
 Employee employee=services.getEmployeeDetails(employeeId);
 return new ResponseEntity<Employee>(employee,HttpStatus.OK);
 }
	@RequestMapping(value="/removeEmployeeDetails",method=RequestMethod.DELETE)
	public ResponseEntity<String> removeEmployeeDetails(@RequestParam int  employeeId) throws EmployeeNotFoundException{
		services.removeEmployeeDetails(employeeId);
		return new ResponseEntity<>("Employee Details successfully removed",HttpStatus.OK);
	}
	@RequestMapping(value= {"/getAllEmployees"},method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<List<Employee>>getAllMoviesPathParam(){
		return new ResponseEntity<List<Employee>>(services. getAllEmployees(),HttpStatus.OK);
	}
}
