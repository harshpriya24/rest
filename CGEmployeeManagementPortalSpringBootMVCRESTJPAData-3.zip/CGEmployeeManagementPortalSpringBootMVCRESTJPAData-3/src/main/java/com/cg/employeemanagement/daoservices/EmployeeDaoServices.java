package com.cg.employeemanagement.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.employeemanagement.beans.Employee;

public interface EmployeeDaoServices extends JpaRepository<Employee, Integer>{
 
}
