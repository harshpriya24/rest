package com.cg.billing.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
import com.cg.billing.services.BillingServices;

@Controller
@SessionAttributes("adminId")
public class AdminServicesController {

	@Autowired
	private BillingServices services;
	
	@RequestMapping("/allCustomerDetailsService")
	public ModelAndView getAllCustomerDetails() {
		List<Customer> customers = services.getAllCustomerDetails();
		return new ModelAndView("allCustomerDetailsPage", "customers", customers);
	}
	
	@RequestMapping("/generateBillService")
	public ModelAndView generateBillService(@ModelAttribute Bill bill, @RequestParam int customerId, @RequestParam long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, PlanDetailsNotFoundException {
		services.generateMonthlyMobileBill(customerId, mobileNo, bill);
		return new ModelAndView("billGenerationSuccessPage", "res", "Bill is generated successfully");
	}
	
	@RequestMapping("removeCustomerService")
	public ModelAndView removeCustomer(@RequestParam int customerId) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		services.removeCustomerDetails(customerId);
		return new ModelAndView("removeCustomerPage", "res", "Customer with id "+ customerId + " is successfully removed");
	}
}
