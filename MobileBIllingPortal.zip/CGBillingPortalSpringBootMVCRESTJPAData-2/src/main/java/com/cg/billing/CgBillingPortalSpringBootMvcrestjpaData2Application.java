package com.cg.billing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CgBillingPortalSpringBootMvcrestjpaData2Application {

	public static void main(String[] args) {
		SpringApplication.run(CgBillingPortalSpringBootMvcrestjpaData2Application.class, args);
	}

}
