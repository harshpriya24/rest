package com.cg.billing.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;

@Controller
public class URIController {
	
	private Customer customer;
	private Bill bill;
	
	@RequestMapping(value= {"/","/index"})
	public String getIndexPage() {
		return "indexPage";
	}
	
	@RequestMapping("/login")
	public String getLoginPage() {
		return "loginPage";
	}
	
	@RequestMapping("/register")
	public String getRegisterPage() {
		return "registerPage";
	}
	
	@RequestMapping("/openAccount")
	public String getOpenAccountPage() {
		return "openAccountPage";
	}
	
	@RequestMapping("/monthlyBill")
	public String getmonthlyBillPage() {
		return "monthlyBillPage";
	}
	
	@RequestMapping("/changePlan")
	public String getchangePlanPage() {
		return "changePlanPage";
	}
	
	@RequestMapping("/allBillDetails")
	public String getAllBillDetailsPage() {
		return "allBillDetailsPage";
	}
	
	@RequestMapping("/closeAccount")
	public String getcloseAccountPage() {
		return "closeAccountPage";
	}
	
	@RequestMapping("/allAccountDetails")
	public String getallAccountDetailsPage() {
		return "allAccountDetailsPage";
	}
	
	
	@RequestMapping("/customerHomePage")
	public String getCustomerHomePage() {
		return "customerHomePage";
	}
	
	//------------------------------ Admin Urls -----------------------
	
	@RequestMapping("/generateMonthlyBill")
	public String getGenerateMonthlyBillPage() {
		return "generateMonthlyBillPage";
	}
	
	@RequestMapping("/removeCustomer")
	public String getRemoveCustomerPage() {
		return "removeCustomerPage";
	}
	
	// ------------------------ Model Attribute -----------------------------------
	@ModelAttribute
	public Customer getCustomer() {
		customer = new Customer();
		return customer;
	}
	
	@ModelAttribute
	public Bill getBill() {
		bill = new Bill();
		return bill;
	}
	
}
