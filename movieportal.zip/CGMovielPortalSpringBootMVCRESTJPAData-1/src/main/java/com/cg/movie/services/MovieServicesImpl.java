package com.cg.movie.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Song;
import com.cg.movie.daoservices.MovieDAOServices;

import com.cg.movie.exceptions.MovieNotFoundException;
import com.cg.movie.exceptions.SongNotFoundException;
@Component("movieServices")
public class MovieServicesImpl implements MovieServices{
@Autowired
	private MovieDAOServices moviedaoServices;
//@Autowired
//	private SongDAOServices songdaoServices;
	
	@Override
	public Movie acceptMovieDetails(Movie movie) {
		return moviedaoServices.save(movie);
	}

//	@Override
//	public Song acceptSongDetails(Song song) {
//			return songdaoServices.save(song);
//	}

	@Override
	public Movie getMovieDetails(int movieId) throws MovieNotFoundException{
		return moviedaoServices.findById(movieId).orElseThrow(()->new MovieNotFoundException("Movie not found for For id"+movieId));
	}

	@Override
	public boolean removeMovieDetails(int movieId) throws MovieNotFoundException{
		
		moviedaoServices.delete(getMovieDetails(movieId));
		return true;
	}

//	@Override
//	public boolean removeSong(int movieId, int songId)throws SongNotFoundException {
//         
//		return false;
//	}
//
//	@Override
//	public List<Song> getAllSongs() {
//		return songdaoServices.findAll();
//	}

	@Override
	public List<Movie> getAllMovies() {
		return moviedaoServices.findAll();
	}


	
}
