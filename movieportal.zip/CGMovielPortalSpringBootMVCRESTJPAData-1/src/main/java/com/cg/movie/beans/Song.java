package com.cg.movie.beans;

import javax.persistence.Embeddable;

@Embeddable
public class Song {


	private int songId;

	private String songName;

	private String songLength;
	public Song() {}
	
	public Song(int songId, String songName, String songLength) {
		super();
		this.songId = songId;
		this.songName = songName;
		this.songLength = songLength;
	}

	public int getSongId() {
		return songId;
	}
	public void setSongId(int songId) {
		this.songId = songId;
	}
	public String getSongName() {
		return songName;
	}
	public void setSongName(String songName) {
		this.songName = songName;
	}
	public String getSongLength() {
		return songLength;
	}
	public void setSongLength(String songLength) {
		this.songLength = songLength;
	}
	@Override
	public String toString() {
		return "Song [songId=" + songId + ", songName=" + songName + ", songLength=" + songLength + "]";
	}


}
