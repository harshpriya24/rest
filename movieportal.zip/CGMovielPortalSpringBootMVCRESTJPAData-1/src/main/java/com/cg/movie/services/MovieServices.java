package com.cg.movie.services;

import java.util.List;

import com.cg.movie.beans.Movie;
import com.cg.movie.exceptions.MovieNotFoundException;

public interface MovieServices {
	public Movie acceptMovieDetails(Movie movie);
//	public Song acceptSongDetails(Song song);
	public Movie getMovieDetails(int movieId)throws MovieNotFoundException;
	public boolean removeMovieDetails(int movieId) throws MovieNotFoundException;
	//public boolean removeSong(int movieId,int songId)throws SongNotFoundException,MovieNotFoundException;
//	List<Song> getAllSongs();
	List<Movie> getAllMovies();
}
