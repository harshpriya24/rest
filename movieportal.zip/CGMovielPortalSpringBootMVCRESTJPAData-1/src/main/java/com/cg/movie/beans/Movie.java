package com.cg.movie.beans;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Movie {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int movieId;
	private String movieName;

	@Embedded
	private Song songs;
	public Movie() {}
	
	public Movie(int movieId) {
		super();
		this.movieId = movieId;
	}

	public Movie(int movieId,  String movieName, Song songs) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.songs = songs;
	}
	public int getMovieId() {
		return movieId;
	}
	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public Song getSongs() {
		return songs;
	}
	public void setSongs(Song songs) {
		this.songs = songs;
	}
	@Override
	public String toString() {
		return "Movie [movieId=" + movieId + ", movieName=" + movieName + ", songs=" + songs + "]";
	}

}
