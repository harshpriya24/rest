package com.cg.banking.aspect;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;
import com.cg.banking.execptions.BankingServicesDownException;
import com.cg.banking.execptions.InvalidAccountException;
import com.cg.banking.execptions.InvalidAmountException;
import com.cg.banking.execptions.AccountNotFoundException;
@ControllerAdvice
public class BankingExceptionAspect {

	@ExceptionHandler(AccountNotFoundException.class)
	public ModelAndView handleAccountNotFoundException(Exception e) {
		
		return new ModelAndView("getAccountDetails","errorMessage",e.getMessage());
	}
	
	@ExceptionHandler(BankingServicesDownException.class)
	public ModelAndView handleBankingServicesDownException(Exception e) {
		
		return new ModelAndView("getAccountDetails","errorMessage",e.getMessage());
	}
	@ExceptionHandler(InvalidAmountException.class)
	public ModelAndView handleInvalidAmountException(Exception e) {
		
		return new ModelAndView("getAccountDetails","errorMessage",e.getMessage());
	}
	@ExceptionHandler(InvalidAccountException.class)
	public ModelAndView handleInvalidAccountException(Exception e) {
		
		return new ModelAndView("getAccountDetails","errorMessage",e.getMessage());
	}
	
}
