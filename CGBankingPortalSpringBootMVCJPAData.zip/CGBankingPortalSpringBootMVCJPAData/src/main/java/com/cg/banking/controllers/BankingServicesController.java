package com.cg.banking.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.execptions.AccountBlockedException;
import com.cg.banking.execptions.AccountNotFoundException;
import com.cg.banking.execptions.BankingServicesDownException;
import com.cg.banking.execptions.InsufficientAmountException;
import com.cg.banking.execptions.InvalidAccountException;
import com.cg.banking.execptions.InvalidAmountException;
import com.cg.banking.execptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

@Controller
public class BankingServicesController {
	@Autowired
	BankingServices bankingServices;
	
	@RequestMapping("/openingAccount")
	public ModelAndView registerAccount(@Valid@ModelAttribute Account account) throws InvalidAmountException, InvalidAccountException, BankingServicesDownException {
		account=bankingServices.openAccount(account);
		return new ModelAndView("openAccountSuccessPage","account",account);	
	}
	
	@RequestMapping("/accountDetails")
	public ModelAndView getAssociateDetails(@RequestParam long accountNo)throws AccountNotFoundException, BankingServicesDownException {
		Account account=bankingServices.getAccountDetails(accountNo);
		return new ModelAndView("getAccountDetails","account",account);
	}
	@RequestMapping("/allAccountDetails")
	public ModelAndView getAllAssociateDetails() throws BankingServicesDownException {
		List<Account> accounts=bankingServices.getAllAccountDetails();
		return new ModelAndView("getAllAccountDetails","accounts",accounts);
	}

	@RequestMapping("/depositingAmount")
	public ModelAndView depositAmount(@Valid@RequestParam long accountNo,float amount ) throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
	float deposit=bankingServices.depositAmount(accountNo, amount);
	 return new ModelAndView("depositAmountPage","deposit",deposit);		
	}
	@RequestMapping("/fundTransfering")
	public ModelAndView fundTransfer(@Valid@RequestParam long accountNoTo,long accountNoFrom,float transferAmount,int pinNumber) throws BankingServicesDownException, InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException {
           boolean transfer=bankingServices.fundTransfer(accountNoTo, accountNoFrom, transferAmount, pinNumber);
           return new ModelAndView("fundTransferPage","transfer",transfer);
		}

	@RequestMapping("/withdrawingAmount")
	public ModelAndView withdrawAmount(@Valid@RequestParam long accountNo, float amount, int pinNumber) throws BankingServicesDownException, InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException {
          float withdrawal=bankingServices.withdrawAmount(accountNo, amount, pinNumber);
           return new ModelAndView("withdrawPage","withdrawal",withdrawal);
		}
}
