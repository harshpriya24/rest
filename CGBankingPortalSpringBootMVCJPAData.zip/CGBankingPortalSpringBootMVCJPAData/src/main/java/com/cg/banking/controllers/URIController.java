package com.cg.banking.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.banking.beans.Account;

@Controller
public class URIController {
private Account account;
	
	@RequestMapping(value= {"/","index"})
	public String getIndexPage() {
		return "indexPage";
	}
	
	@RequestMapping("/openAccount")
	public String getRegistrationPage() {
		return "openAccountPage";
		}
	
	@RequestMapping("/findDetails")
	public String getFindDetailsPage() {
		return "getAccountDetails";
		}
	@RequestMapping("/findAllDetails")
	public String getFindAllDetailsPage() {
		return "getAllAccountDetails";
		}
	@RequestMapping("/fundTransfer")
	public String fundTranferPage() {
		return "fundTransferPage";
		}
	@RequestMapping("/withdrawAmount")
	public String withdrawAmountPage() {
		return "withdrawPage";
		}
	@RequestMapping("/depositAmount")
	public String depositAmountPage() {
		return "depositAmountPage";
		}
	@ModelAttribute
	public Account getAccount() {
	 account = new Account();
		return account;
	}
}
