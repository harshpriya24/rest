package com.cg.banking.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.execptions.AccountBlockedException;
import com.cg.banking.execptions.AccountNotFoundException;
import com.cg.banking.execptions.BankingServicesDownException;
import com.cg.banking.execptions.InsufficientAmountException;
import com.cg.banking.execptions.InvalidAccountException;
import com.cg.banking.execptions.InvalidAmountException;
import com.cg.banking.execptions.InvalidPinNumberException;
@Component("bankingServices")
public class BankingServicesImpl implements BankingServices {

	int counter=0,count=0;
	@Autowired
	AccountDAO accountdao;
	@Autowired
	TransactionDAO transactiondao;
	@Override
	public Account openAccount(Account account)
			throws InvalidAmountException, InvalidAccountException, BankingServicesDownException {
		account.setPinNumber((int)(Math.random()*1000));
		return accountdao.save(account);
	}

	@Override
	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account account=  getAccountDetails(accountNo);
		if(account.getAccountStatus().equalsIgnoreCase("Blocked"))throw new AccountBlockedException("Your Account is BLocked");
		else
			account.setAccountBalance(account.getAccountBalance()+amount);
		System.out.println("balance is :-"+account.getAccountBalance());
		transactiondao.save(new Transaction(amount, "Deposit",account));
		accountdao.save(account);
		return account.getAccountBalance(); 

	}

	@Override
	public float withdrawAmount(long accountNo, float amount, int pinNumber)
			throws AccountNotFoundException, InvalidPinNumberException, InsufficientAmountException, AccountBlockedException ,BankingServicesDownException{
		Account account=getAccountDetails(accountNo);

		if(account.getPinNumber()!=pinNumber) {
			counter++;
			if(counter==3) {
				account.setAccountStatus("Blocked");
				throw new InvalidPinNumberException("your account is blocked"+accountNo);
			}
			throw new InvalidPinNumberException("Invalid Pin Number for account"+accountNo);
		}

		if(account.getAccountBalance()-amount<1000)throw new InsufficientAmountException("Low Balance in account"+accountNo);
		else{
			account.setAccountBalance(account.getAccountBalance()-amount);
		}
		transactiondao.save( new Transaction(amount, "Withdraw", account));
		accountdao.save(account);

		return account.getAccountBalance();

	}


	@Override
	public boolean fundTransfer(long accountNoTo, long acccountNoFrom,float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account customerNoTo=getAccountDetails(accountNoTo);
		Account customerNoFrom=getAccountDetails(acccountNoFrom);
		if(customerNoTo.getAccountStatus().equalsIgnoreCase("Blocked")||customerNoFrom.getAccountStatus().equalsIgnoreCase("Blocked")) {

			throw new AccountBlockedException("Account is Blocked");

		}
		else if(customerNoFrom.getPinNumber()!=pinNumber)throw new InvalidPinNumberException("Pin is Invalid");
		else if(customerNoFrom.getAccountBalance()-transferAmount<500)throw new InsufficientAmountException("Amount is Insufficient in Account");
		else {
			customerNoTo.setAccountBalance(customerNoTo.getAccountBalance()+transferAmount);
			transactiondao.save( new Transaction(transferAmount, "deposit", customerNoTo));
			accountdao.save(customerNoTo);
			customerNoFrom.setAccountBalance(customerNoFrom.getAccountBalance()-transferAmount);
			transactiondao.save(new Transaction(transferAmount, "withdraw", customerNoFrom));
			accountdao.save(customerNoFrom);
			
			return true;
		}
	}



	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo) throws BankingServicesDownException {

		return transactiondao.findAll(accountNo);
	}

	@Override
	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException, AccountBlockedException {
		Account account=getAccountDetails(accountNo);
		if(account.getAccountStatus().equalsIgnoreCase("Blocked")) throw new AccountBlockedException("Account is blocked for the accNo"+accountNo);
		else
			return "active";
	}

	@Override
	public Account getAccountDetails(long accountNo) throws BankingServicesDownException, AccountNotFoundException {

		return	accountdao.findById(accountNo).orElseThrow(()->new AccountNotFoundException("Account Not found for Account no "+accountNo));
	}
	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException {
		List<Account> accounts=accountdao.findAll();
		return accounts;
	}
}
